import assert from 'node:assert/strict';
import {readFile,access} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';
import {profile,projects,skillGroups,site} from '../dist/content.js';
import {selectProjects,escapeHTML} from '../dist/helpers.js';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'../dist');
assert.equal(new Set(projects.map(p=>p.id)).size,projects.length,'Project IDs must be unique.');
for(const p of projects){
  for(const field of ['name','summary','problem','contribution','aiAssistance','differently','decision','learning','limits','verification'])assert.ok(p[field],`${p.id}: missing ${field}`);
  assert.ok(p.tech.length&&p.features.length);
  for(const key of ['source','demo','evidence'])if(p[key])assert.equal(new URL(p[key]).protocol,'https:');
  if(p.image){assert.ok(p.imageAlt&&p.imageCaption);await access(resolve(root,'.'+p.image));}
}
for(const s of skillGroups)assert.ok(projects.some(p=>p.id===s.project));
assert.equal(selectProjects(projects,'','All').length,projects.length);
for(const topic of new Set(projects.map(p=>p.topic))){
 assert.ok(topic,'Each project needs a topic');
 assert.deepEqual(selectProjects(projects,'','All',topic).map(p=>p.id),projects.filter(p=>p.topic===topic).map(p=>p.id));
}
assert.equal(selectProjects(projects,'Kubernetes','All','cloud-devops')[0].id,'scale-lab');
assert.equal(selectProjects(projects,'Kubernetes','All','data-analytics').length,0);
assert.equal(selectProjects(projects,'  DURABLE  ','Python')[0].id,'durable-queue');
assert.equal(selectProjects(projects,'Durable','Java').length,0);
assert.equal(selectProjects(projects,'not-a-project').length,0);
assert.ok(selectProjects(projects,'','SQL').some(p=>p.tech.includes('PostgreSQL')));
assert.equal(escapeHTML('<img src=x onerror="alert(1)">'),'&lt;img src=x onerror=&quot;alert(1)&quot;&gt;');
const html=await readFile(resolve(root,'index.html'),'utf8');
for(const match of html.matchAll(/(?:href|src)="(\/[^"#]*)"/g))await access(resolve(root,'.'+match[1].split('?')[0]));
for(const match of html.matchAll(/href="#([^"/]*)"/g))assert.ok(html.includes(`id="${match[1]}"`),`Missing anchor ${match[1]}`);
assert.ok(html.includes('name="viewport"')&&html.includes('property="og:image"'));
assert.ok(html.includes(profile.email));
assert.equal((html.match(/class="project-card/g)||[]).length,projects.length,'Every project must exist in the HTML without JavaScript.');
assert.ok(!html.includes('Loading project stories'),'Static content must not depend on a loading placeholder.');
const profileSchema=JSON.parse(html.match(/<script type="application\/ld\+json">([^<]*)<\/script>/)[1]);
assert.equal(profileSchema['@type'],'ProfilePage');
assert.equal(profileSchema.mainEntity.name,profile.name);
const canonicalURLs=new Set();
for(const p of projects){
  const page=await readFile(resolve(root,'projects',p.id,'index.html'),'utf8');
  const canonical=page.match(/rel="canonical" href="([^"]+)"/)[1];
  assert.equal(canonical,`${site.origin}/projects/${p.id}/`);
  canonicalURLs.add(canonical);
  for(const claim of [p.contribution,p.aiAssistance,p.differently,p.limits])assert.ok(page.includes(escapeHTML(claim)),`${p.id}: missing static case-study content`);
  assert.equal((page.match(/<h1\b/g)||[]).length,1);
  for(const match of page.matchAll(/<script type="application\/ld\+json">([^<]*)<\/script>/g))JSON.parse(match[1]);
  for(const image of page.matchAll(/<img\b[^>]*>/g))assert.ok(/alt="[^"]+"/.test(image[0]),`${p.id}: image lacks description`);
  for(const match of page.matchAll(/(?:href|src)="(\/[^"#]*)"/g))await access(resolve(root,'.'+match[1].split('?')[0]));
}
assert.equal(canonicalURLs.size,projects.length);
const sitemap=await readFile(resolve(root,'sitemap.xml'),'utf8');
for(const url of canonicalURLs)assert.ok(sitemap.includes(`<loc>${url}</loc>`));
if(process.argv.includes('--release')){
  assert.ok(profile.portraitApproved&&profile.portrait,'Portrait approval and final image are required before publication.');
  await access(resolve(root,'.'+profile.portrait));
  assert.ok(!html.includes('noindex, nofollow'),'Remove draft noindex metadata for publication.');
  assert.ok(!html.includes('Private design preview'),'Remove the draft banner for publication.');
}
console.log(`Passed: ${projects.length} complete project records, search/filter behavior, safe rendering, asset references, anchors, metadata${process.argv.includes('--release')?', and publication readiness':''}.`);
