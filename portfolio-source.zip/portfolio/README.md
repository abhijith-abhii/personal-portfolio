# Abhijith Viswanathan — Portfolio

A lightweight, responsive personal portfolio with 30 evidence-based case studies across six clearly labeled fields, saved light/dark themes, technology filters, project search, accessible dialogs, and direct contact actions.

[View the live portfolio](https://abhijith-viswanathan-portfolio.abhijithabhi3331.chatgpt.site/) · [GitHub profile](https://github.com/abhijith-abhii)

## Browse the work

Field buttons jump to Software engineering, Data science & ML, AI engineering, Security & safe access, Cloud & DevOps, and Data analytics. Skill buttons narrow the collection; search combines with the selected skill. Every project has its own shareable case-study page.

## Edit the portfolio

- **Projects and skills:** update `dist/content.js`. Copy a project record, use a unique `id` and one of the existing `topic` identifiers, and fill in the contribution, implemented features, decision, limitations, and evidence. Use `null` for unavailable public source/demo links. Keep the distinction between AI-assisted learning, personal contribution, and production work clear.
- **Introduction, education, current learning, contact links:** edit `src/index.html`, then run `node scripts/build.mjs`. The email also appears in `profile.email` inside `dist/content.js` for the copy button. Update both together.
- **Portrait:** put an optimized image in `dist/assets/`, change `profile.portrait` in `dist/content.js`, and update the static portrait image in `src/index.html`. Confirm its likeness before publishing. The high-resolution photo set is kept outside the website folder.
- **Resume:** replace `dist/assets/Abhijith-Viswanathan-Resume.pdf` with the finalized resume. The download links keep working when the filename stays the same.
- **Colors and layout:** edit the theme variables at the top of `dist/styles.css`. Both color themes use the same page structure.
- **Sharing image:** replace `dist/og.jpg`. Keep the absolute Open Graph and X image URLs in `src/index.html` aligned with the published site address.

There are no third-party fonts, analytics, cookies, contact-form services, or build dependencies. Theme preference is stored locally in the visitor’s browser. Contact opens the visitor’s email application; the site itself does not send mail.

## Preview and checks

Serve the `dist` folder with any local static web server. For example, `python3 -m http.server 5187 --directory dist`, then open `http://127.0.0.1:5187/`.

With Node.js installed, run `node scripts/build.mjs` after content or template edits. This generates the homepage, 30 complete case-study pages, sitemap, and structured data. Then run `node scripts/check.mjs`. Before publishing, use `node scripts/check.mjs --release`. The release check requires the approved portrait, valid local assets, and removal of preview-only metadata.

The `.openai/hosting.json` file identifies this Sites project. Keep its exact `project_id` when updating the existing site. Only `dist/` is public web content; keep personal documents, certificates, original photographs, and credentials outside it.

## Content provenance

See `docs/VERIFICATION.md` for the sources and the distinction between this website’s checks and historical project test reports.

## Shareable projects and learning notes

Each project has a real HTML page at `/projects/<id>/`. Cards and skills are present in the initial HTML; JavaScript enhances them with filtering and optional quick previews. Existing `#project/<id>` links still open their preview. Project details and short learning notes are edited in `dist/content.js`; reusable rendering lives in `dist/render.js`.

Keep AI-assistance and personal-contribution claims separate. A next-iteration note is a proposed improvement, not a completed feature. Do not add a recommendation without the actual quote and permission to publish it.

Analytics remains disabled. There are no analytics cookies, visitor identifiers, tracking requests, or third-party scripts. The hosting service can maintain its own operational logs.
